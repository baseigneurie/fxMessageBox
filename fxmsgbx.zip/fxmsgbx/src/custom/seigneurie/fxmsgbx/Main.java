package custom.seigneurie.fxmsgbx;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}
	
	  public void start(Stage primaryStage) {		
			primaryStage.setTitle("This is a test window");
			Button btn = new Button("Click Me");
			btn.addEventHandler(ActionEvent.ACTION, event -> openMsg());
			
			Scene scene = new Scene(btn, 100, 100);
			primaryStage.setScene(scene);
			primaryStage.show();
	}
	  
	 private void openMsg() {
		 MessageBox msg = new MessageBox("Testing", "This is a message box!!");
		 msg.show();
		 
	 }

}
